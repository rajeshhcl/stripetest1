import React, { Component } from 'react';
import './NotFound.css';

class NotFound extends Component {
  render() {
    return (
      <div className="NotFound">
        <h1> You are in NotFound page </h1>
      </div>
    );
  }
}

export default NotFound;
