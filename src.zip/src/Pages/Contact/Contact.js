import React, { Component } from 'react';
import './Contact.css';

class Contact extends Component {
  render() {
    return (
      <div className="Contact">
        <h1> You are in contact page </h1>
      </div>
    );
  }
}

export default Contact;
