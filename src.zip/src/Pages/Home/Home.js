import React, { Component } from 'react';
import './Home.css';

class Home extends Component {
  render() {
    return (
      <div className="Home">
        <h1> You are in Home page </h1>
      </div>
    );
  }
}

export default Home;
